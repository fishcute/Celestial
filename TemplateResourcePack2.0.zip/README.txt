 _____      _           _   _       _ 
/  __ \    | |         | | (_)     | |
| /  \/ ___| | ___  ___| |_ _  __ _| |
| |    / _ \ |/ _ \/ __| __| |/ _` | |
| \__/\  __/ |  __/\__ \ |_| | (_| | |
 \____/\___|_|\___||___/\__|_|\__,_|_|
This is the Celestial template resource pack, feel free to use or modify this for anything!

------------------------------------------------------------------------------------------

Celestial Mod Page:
https://www.curseforge.com/minecraft/mc-mods/celestial
https://modrinth.com/mod/celestial

------------------------------------------------------------------------------------------

Need inspiration, or want to see how things work in action? Check out the demo packs:
https://www.curseforge.com/minecraft/texture-packs/celestial-demo-packs

------------------------------------------------------------------------------------------

Make sure to check out the wiki if you are new to Celestial:
https://github.com/fishcute/Celestial/wiki

------------------------------------------------------------------------------------------

If you have any questions, feel free to ask on the discord:
https://discord.gg/9KsHkDE6u2

------------------------------------------------------------------------------------------

Don't forget to delete this file if you plan to release a resource pack using this!